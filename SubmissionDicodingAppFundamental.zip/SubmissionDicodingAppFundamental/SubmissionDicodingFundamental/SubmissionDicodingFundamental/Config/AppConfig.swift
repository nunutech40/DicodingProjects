//
//  AppConfig.swift
//  SubmissionDicodingFundamental
//
//  Created by mac on 2/10/21.
//

import UIKit

class AppConfig {
    
    // ====================== CONFIGURATION ========================= //
    public static let ROUND_PRIMARY                 = CGFloat(8)
    
}
